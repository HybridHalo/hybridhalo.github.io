# Obsidian Radar Chart Plugin

Create beautiful radar/spider charts directly in your Obsidian notes!

## 📦 What's Included

**Ready to use (no build required):**
- `main.js` - Pre-built plugin (already compiled from TypeScript)
- `manifest.json` - Plugin metadata
- `styles.css` - Chart styling

**Source files (for developers):**
- `main.ts` - TypeScript source code
- `package.json` - Dependencies
- `tsconfig.json` - TypeScript config
- `esbuild.config.mjs` - Build configuration

## Features

- Create customizable radar charts with angular/polygonal grid
- Charts adapt to any number of data points (3+)
- Customize colors
- Clean, minimal design
- Works with Obsidian's light and dark themes

## Installation

### Quick Installation (No Build Required)

The plugin is ready to use! Just install the pre-built files:

1. Create a folder named `radar-chart` in your vault's `.obsidian/plugins/` directory
2. Copy these files into the folder:
   - `main.js` (already built - no compilation needed!)
   - `manifest.json`
   - `styles.css`
3. Reload Obsidian (Ctrl/Cmd + R or restart)
4. Enable the plugin in Settings → Community Plugins

### Building from Source (Optional)

Only needed if you want to modify the TypeScript source code:

1. Clone this repository
2. Run `npm install` to install dependencies
3. Run `npm run build` to compile TypeScript to JavaScript
4. The built `main.js` will be created in the root directory

## Usage

Create a radar chart by using a code block with the `radar` language identifier:

````markdown
```radar
Speed: 80
Strength: 90
Defense: 70
Agility: 85
Intelligence: 75
color: #00d4ff
```
````

### Syntax

- Each line should be in the format: `Label: Value`
- Values should be between 0 and 100
- Use `color: #hexcode` to customize the data polygon color
- Use `textColor: #hexcode` to customize the label text color
- Use `gridColor: #hexcode` to customize the background grid lines color
- Lines starting with `#` are treated as comments and ignored

### Example Charts

#### Character Stats (Default Colors)
````markdown
```radar
Speed: 80
Strength: 90
Defense: 70
Agility: 85
Intelligence: 75
color: #00d4ff
```
````

#### Skills Assessment (Custom Text Color)
````markdown
```radar
JavaScript: 95
Python: 80
Design: 70
Communication: 85
Leadership: 75
Problem Solving: 90
color: #c561f5
textColor: #ffffff
gridColor: #444444
```
````

#### Product Features (Fully Customized)
````markdown
```radar
Performance: 85
Design: 92
Price: 65
Support: 88
Features: 90
Reliability: 78
Quality: 95
Usability: 87
color: #ff6b9d
textColor: #ffb3d9
gridColor: #663344
```
````

#### Dark Theme Optimized
````markdown
```radar
Offense: 90
Defense: 75
Speed: 85
Stamina: 80
Technique: 88
color: #00ff88
textColor: #88ffcc
gridColor: #004422
```
````

## Customization

### Colors

You can customize three different color aspects of the chart:

**Data Polygon Color (`color:`)** - The color of your data shape:
```
color: #ff0000    (red)
color: #00ff00    (green)
color: #0000ff    (blue)
color: #ff6b9d    (pink)
```

**Text Color (`textColor:`)** - The color of the axis labels:
```
textColor: #ffffff    (white)
textColor: #000000    (black)
textColor: #ffb3d9    (light pink)
textColor: #88ffcc    (light cyan)
```

**Grid Color (`gridColor:`)** - The color of the background grid lines and axes:
```
gridColor: #333333    (dark gray - default)
gridColor: #666666    (medium gray)
gridColor: #004422    (dark green)
gridColor: #663344    (dark purple)
```

All three can be used together in any combination!

### Data Points

The chart automatically adapts to any number of data points:
- 3 points = Triangle
- 4 points = Square
- 5 points = Pentagon
- 6 points = Hexagon
- And so on...

## Development

To set up the development environment:

```bash
# Install dependencies
npm install

# Build the plugin
npm run build

# Watch for changes during development
npm run dev
```

## License

MIT

## Support

If you encounter any issues or have suggestions, please open an issue on GitHub.
