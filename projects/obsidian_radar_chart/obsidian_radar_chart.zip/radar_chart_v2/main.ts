import { Plugin } from 'obsidian';

interface RadarChartData {
    labels: string[];
    values: number[];
    color?: string;
    textColor?: string;
    gridColor?: string;
}

export default class RadarChartPlugin extends Plugin {
    async onload() {
        console.log('Loading Radar Chart Plugin');

        // Register a code block processor for 'radar' blocks
        this.registerMarkdownCodeBlockProcessor('radar', (source, el, ctx) => {
            try {
                const data = this.parseRadarData(source);
                this.renderRadarChart(el, data);
            } catch (error) {
                el.createEl('div', { 
                    text: `Error rendering radar chart: ${error.message}`,
                    cls: 'radar-chart-error'
                });
            }
        });
    }

    onunload() {
        console.log('Unloading Radar Chart Plugin');
    }

    parseRadarData(source: string): RadarChartData {
        const lines = source.trim().split('\n');
        const data: RadarChartData = {
            labels: [],
            values: [],
            color: '#00d4ff',
            textColor: '#ffffff',
            gridColor: '#333333'
        };

        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) continue;

            if (trimmed.startsWith('color:')) {
                data.color = trimmed.substring(6).trim();
            } else if (trimmed.startsWith('textColor:')) {
                data.textColor = trimmed.substring(10).trim();
            } else if (trimmed.startsWith('gridColor:')) {
                data.gridColor = trimmed.substring(10).trim();
            } else {
                // Parse "Label: Value" format
                const parts = trimmed.split(':');
                if (parts.length === 2) {
                    const label = parts[0].trim();
                    const value = parseFloat(parts[1].trim());
                    if (!isNaN(value)) {
                        data.labels.push(label);
                        data.values.push(Math.max(0, Math.min(100, value)));
                    }
                }
            }
        }

        if (data.labels.length === 0) {
            throw new Error('No valid data points found');
        }

        return data;
    }

    renderRadarChart(container: HTMLElement, data: RadarChartData) {
        const canvas = container.createEl('canvas', {
            attr: {
                width: '600',
                height: '600'
            }
        });

        canvas.addClass('radar-chart-canvas');

        // Draw the chart
        this.drawRadarChart(canvas, data);
    }

    drawRadarChart(canvas: HTMLCanvasElement, data: RadarChartData) {
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const radius = Math.min(centerX, centerY) - 100;

        // Clear canvas (transparent background)
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const numPoints = data.labels.length;
        const angleStep = (Math.PI * 2) / numPoints;

        // Draw angular grid (polygons instead of circles)
        ctx.strokeStyle = data.gridColor || '#333333';
        ctx.lineWidth = 1;

        for (let level = 1; level <= 5; level++) {
            ctx.beginPath();
            for (let i = 0; i < numPoints; i++) {
                const angle = angleStep * i + Math.PI / 2;
                const levelRadius = (radius / 5) * level;
                const x = centerX + Math.cos(angle) * levelRadius;
                const y = centerY + Math.sin(angle) * levelRadius;

                if (i === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            }
            ctx.closePath();
            ctx.stroke();
        }

        // Draw axes and labels
        ctx.strokeStyle = data.gridColor || '#333333';
        ctx.fillStyle = data.textColor || '#ffffff';
        ctx.font = 'bold 12px var(--font-interface)';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        for (let i = 0; i < numPoints; i++) {
            const angle = angleStep * i + Math.PI / 2;
            const x = centerX + Math.cos(angle) * radius;
            const y = centerY + Math.sin(angle) * radius;

            // Draw axis line
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(x, y);
            ctx.stroke();

            // Draw label
            const labelX = centerX + Math.cos(angle) * (radius + 40);
            const labelY = centerY + Math.sin(angle) * (radius + 40);

            // Adjust text alignment based on position
            if (Math.abs(Math.cos(angle)) > 0.5) {
                ctx.textAlign = Math.cos(angle) > 0 ? 'left' : 'right';
            } else {
                ctx.textAlign = 'center';
            }

            ctx.fillText(data.labels[i], labelX, labelY);
        }

        // Draw data polygon
        ctx.beginPath();
        ctx.strokeStyle = data.color || '#00d4ff';
        ctx.fillStyle = (data.color || '#00d4ff') + '40';
        ctx.lineWidth = 2.5;

        for (let i = 0; i < numPoints; i++) {
            const angle = angleStep * i + Math.PI / 2;
            const value = Math.min(100, Math.max(0, data.values[i]));
            const distance = (value / 100) * radius;
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;

            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }

        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Draw data points
        ctx.fillStyle = data.color || '#00d4ff';
        for (let i = 0; i < numPoints; i++) {
            const angle = angleStep * i + Math.PI / 2;
            const value = Math.min(100, Math.max(0, data.values[i]));
            const distance = (value / 100) * radius;
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;

            ctx.beginPath();
            ctx.arc(x, y, 5, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}
