# 🔴 Conspiracy Board Graph - Quick Reference

## What You Get
A standalone conspiracy board view for Obsidian that shows notes from your current folder!

### Visual Elements
- 🪵 **Cork board background** - Realistic texture with subtle grain
- 🔴 **Red string** - Drooping connections between notes
- 📌 **Drawing pins** - Metallic pins at each connection point
- 📝 **Sticky notes** - Yellow/cream notes for text files
- 📸 **Polaroid photos** - Vintage photo style for image files
- ✍️ **Handwritten fonts** - Permanent Marker & Special Elite
- 🎮 **Interactive** - Drag notes, double-click to open files
- 📍 **Static layout** - Notes stay where you put them
- 📁 **Folder-aware** - Shows current folder, toggle to see all files

## How to Open
Three ways to open the conspiracy board:

1. **Ribbon Icon**: Click the 📌 pin icon in left sidebar
2. **Command**: `Ctrl/Cmd + P` → type "Open Conspiracy Board"
3. **Right-click**: On any pane → "Open Conspiracy Board"

## Folder Mode
- **Default**: Shows notes from current folder only
- **Toggle**: Click **📁 Current Folder** button to switch to **📂 All Files**
- **Auto-updates**: Changes when you navigate to different folders
- **Display**: Current folder shown at top with 📍 icon

## Installation (3 Steps)
```bash
1. npm install && npm run build
2. Copy files to: YourVault/.obsidian/plugins/conspiracy-board-graph/
3. Enable in Obsidian → Settings → Community Plugins
```

## Required Files
Copy these to your vault:
- ✅ `manifest.json`
- ✅ `main.js` (built from main.ts)
- ✅ `styles.css`
- ✅ `versions.json`

## Usage
1. Click 📌 ribbon icon OR press `Ctrl/Cmd + P` → "Open Conspiracy Board"
2. **Drag** notes to reposition them - they stay where you put them!
3. **Double-click** notes to open files
4. Notes are laid out in a **grid pattern** initially
5. **Manually arrange** your conspiracy board however you like

## Customization Tips

### Change sticky note colors
Edit `main.ts` line 173:
```typescript
const colors = ['#fef08a', '#fde047', '#fcd34d'];
// Add your colors here
```

### Change red string color
Edit `main.ts` line 65:
```typescript
ctx.strokeStyle = '#dc2626'; // Change to any color
```

### Adjust cork board color
Edit `styles.css` line 17:
```css
background-color: #8b6f47; /* Your cork color */
```

### Change note spacing
Edit `main.ts` where nodes are created:
```typescript
const spacing = 180; // Distance between notes in grid
```

### Change fonts
Edit `styles.css` line 4:
```css
@import url('https://fonts.googleapis.com/css2?family=Your+Font&display=swap');
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Plugin doesn't appear | Check folder name is exactly `conspiracy-board-graph` |
| Build fails | Run `./build.sh` instead of `npm run build` |
| No visual changes | Disable and re-enable plugin, then refresh Graph View |
| Fonts don't load | Check internet connection (loads from Google Fonts) |
| Performance slow | Large graphs (500+ nodes) may be slower - use filters |

## Features Explained

### Red String Physics
The string droops naturally based on distance between notes - longer connections = more droop

### Random Rotations
Each sticky note and polaroid has a slight random tilt for organic appearance

### Smart Node Detection
- Files ending in `.png`, `.jpg`, etc. → Polaroid style
- All other files → Sticky note style

### Responsive Design
- Desktop: Full features
- Mobile: Scaled down notes, same aesthetic
- Dark mode: Darker cork board

## Performance Notes
- Canvas-based rendering for maximum visual quality
- Animations use CSS for smooth 60fps
- Large graphs benefit from Obsidian's built-in filters

## Browser Compatibility
- ✅ Chrome/Edge (best performance)
- ✅ Firefox
- ✅ Safari
- ✅ Obsidian Desktop App
- ✅ Obsidian Mobile App

---

**Need more help?** Check `README.md` for full documentation
**Installation guide:** See `INSTALL.md`
**Build issues?** Run `./build.sh`
