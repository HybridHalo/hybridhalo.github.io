# Static Conspiracy Board Layout

The conspiracy board uses a **static layout** where notes stay exactly where you put them - just like real sticky notes pinned to a cork board!

## How It Works

### Initial Layout: Grid Pattern

When you first load the conspiracy board, notes are arranged in a neat grid:

```
┌─────────────────────────────────────────────────────┐
│  📌      📌      📌      📌      📌      📌          │
│ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐         │
│ │Note│ │Note│ │Note│ │Note│ │Note│ │Note│         │
│ │ 1  │ │ 2  │ │ 3  │ │ 4  │ │ 5  │ │ 6  │         │
│ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘         │
│                                                     │
│  📌      📌      📌      📌      📌      📌          │
│ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐ ┌────┐         │
│ │Note│ │Note│ │Note│ │Note│ │Note│ │Note│         │
│ │ 7  │ │ 8  │ │ 9  │ │ 10 │ │ 11 │ │ 12 │         │
│ └────┘ └────┘ └────┘ └────┘ └────┘ └────┘         │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**Grid Spacing:** 180 pixels between notes (configurable)

### Manual Organization

**You're in control!** Drag notes wherever you want:
- Notes **stay** where you put them
- No automatic reorganization
- No physics pushing notes around
- Just like pinning real sticky notes

### Red String Connections

The red strings connect linked notes and update as you move them:
- Strings **droop** naturally based on distance
- Automatically adjust when you drag notes
- Always connect to the pins at the top of each note

## Benefits of Static Layout

✅ **Predictable** - Notes don't move unexpectedly  
✅ **Manual Control** - Organize exactly how you want  
✅ **Stable** - Board stays how you left it  
✅ **Authentic** - Like a real cork board with pinned notes  
✅ **Performance** - No continuous physics calculations  

## Dragging Behavior

### How to Move Notes

1. **Hover** over a note - cursor changes to ✋ (hand)
2. **Click and hold** - cursor changes to ✊ (grabbing)
3. **Drag** to new position
4. **Release** - note stays in new position

### What Happens When You Drag

- The note follows your mouse exactly
- Red strings stretch and droop as you move
- Other notes stay in place (no pushing)
- Note position is updated immediately
- View re-renders to show new position

### Visual Feedback

```
Before dragging:
    📌              📌
   ┌────┐          ┌────┐
   │ A  │──────────│ B  │
   └────┘          └────┘

While dragging A down:
                   📌
                  ┌────┐
                  │ B  │
                  └────┘
    📌             │
   ┌────┐          │ (string stretches)
   │ A  │──────────┘
   └────┘
   (grabbing)

After releasing:
                   📌
                  ┌────┐
                  │ B  │
                  └────┘
    📌             │
   ┌────┐          │
   │ A  │──────────┘
   └────┘
   (stays here!)
```

## Organizing Your Board

### Suggested Layouts

**Hierarchical:**
```
     📌
    ┌────┐
    │Main│
    └────┘
      │
  ┌───┼───┐
  │   │   │
 ┌─┐ ┌─┐ ┌─┐
 │A│ │B│ │C│
 └─┘ └─┘ └─┘
```

**Clustered by Topic:**
```
  Topic 1           Topic 2
  📌 📌 📌          📌 📌
 ┌──┬──┐          ┌──┬──┐
 │  │  │          │  │  │
```

**Timeline (Left to Right):**
```
Past      Present    Future
📌   →    📌    →    📌
┌──┐     ┌──┐      ┌──┐
│ 1│─────│ 2│──────│ 3│
```

**Radial (Central Concept):**
```
        📌
       ┌────┐
   ┌───│ Hub│───┐
   │   └────┘   │
   │            │
  📌           📌
 ┌──┐        ┌──┐
```

## Customizing Initial Layout

### Change Grid Spacing

Edit `main.ts` in the `loadVaultData` function:

```typescript
const spacing = 180;  // Default spacing

// Wider spacing:
const spacing = 250;

// Tighter spacing:
const spacing = 140;
```

### Change Grid Columns

Calculated automatically, but you can override:

```typescript
// Default: auto-calculate based on note count
const cols = Math.ceil(Math.sqrt(displayFiles.length));

// Fixed columns:
const cols = 5;  // Always 5 columns

// More spread out:
const cols = Math.ceil(Math.sqrt(displayFiles.length) * 1.5);
```

### Custom Initial Positions

Replace the grid layout with custom positioning:

```typescript
// Circle layout
const angle = (i / displayFiles.length) * Math.PI * 2;
const radius = 300;
return {
    x: centerX + Math.cos(angle) * radius,
    y: centerY + Math.sin(angle) * radius,
    // ... rest of properties
};

// Random scatter
return {
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    // ... rest of properties
};

// Vertical column
return {
    x: canvas.width / 2,
    y: i * spacing,
    // ... rest of properties
};
```

## Comparison: Static vs Physics-Based

| Aspect | Static (Current) | Physics-Based |
|--------|------------------|---------------|
| Note movement | Only when dragged | Constantly moving |
| Organization | Manual | Automatic |
| Predictability | High | Low |
| Performance | Excellent | Good |
| Control | Full | Partial |
| Learning curve | None | Understanding forces |
| Authenticity | Real cork board | Simulation |

## Tips for Organization

### Tip 1: Start with Grid
Let the initial grid load, then:
1. Identify clusters (connected notes)
2. Drag clusters together
3. Spread out unrelated notes

### Tip 2: Use Red Strings as Guide
- Short strings = notes can be closer
- Long crossing strings = might need reorganization
- Tangled strings = spread notes more

### Tip 3: Leave Space
Don't pack notes too tight:
- Easier to see connections
- Room to add new notes later
- Better readability

### Tip 4: Create Sections
Mentally divide the board into regions:
- Top left: Urgent/Current
- Top right: Future/Planning
- Bottom: Archive/Reference
- Center: Main concepts

### Tip 5: Iterate
First pass: rough grouping
Second pass: refine positions
Third pass: final adjustments

## No Physics Means...

❌ **No repulsion** - Notes don't push each other apart  
❌ **No attraction** - Connected notes don't pull together  
❌ **No animation** - Notes don't drift or float  
❌ **No damping** - No gradual settling into position  
❌ **No forces** - No automatic movement at all  

✅ **Only YOU move notes** - Complete manual control!

## Troubleshooting

### "Notes overlap after reload"
Notes remember their positions. If they overlap:
1. Drag them apart manually
2. Or reload with **📂 All Files** to reset grid

### "I want automatic layout"
The static approach is intentional, but you can:
1. Use the initial grid as a starting point
2. Organize manually based on connections
3. Or fork the plugin to add physics back

### "Notes are too close together"
Increase spacing in code (see Customization section above)

### "Can I save my layout?"
Currently notes reset to grid on reload. Saving custom layouts is a potential future feature.

---

**The static layout gives you complete control - organize your conspiracy board exactly how you envision it, just like a real detective's cork board!**
