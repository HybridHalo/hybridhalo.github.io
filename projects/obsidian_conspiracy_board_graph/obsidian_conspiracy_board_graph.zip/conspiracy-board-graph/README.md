# Conspiracy Board Graph 🔴📌

A standalone conspiracy board view for Obsidian with red string, polaroid photos, sticky notes, and drawing pins!

![Conspiracy Board Preview](https://img.shields.io/badge/Obsidian-Plugin-purple)

## ✨ Features

- **📁 Folder-Aware**: Automatically shows notes from your current folder (toggle to view all)
- **🪵 Standalone View**: Separate conspiracy board view (doesn't modify the regular graph view)
- **🔴 Red String Connections**: Graph edges become realistic red string with drooping physics
- **📌 Drawing Pins**: Each connection point and note has authentic-looking metallic pins
- **📸 Polaroid Photos**: Image files display as vintage polaroid photographs
- **📝 Sticky Notes**: Text files appear as colorful sticky notes with handwritten fonts
- **🎨 Cork Board Background**: Realistic cork texture with subtle variations
- **✍️ Interactive**: Drag notes around - they stay where you put them!
- **📍 Static Layout**: Notes stay pinned in place like real sticky notes on a cork board
- **🔄 Auto-Updates**: Refreshes when you navigate to different folders
- **🎭 Handcrafted Aesthetic**: Uses distinctive fonts (Permanent Marker, Special Elite)
- **📍 Ribbon Icon**: Quick access from the sidebar

## 📦 Installation

### Method 1: Manual Installation (Recommended)

1. Download the latest release files from this repository
2. Navigate to your Obsidian vault folder: `YourVault/.obsidian/plugins/`
3. Create a new folder called `conspiracy-board-graph`
4. Copy these files into the folder:
   - `manifest.json`
   - `main.js` (compile from `main.ts` or download pre-built)
   - `styles.css`
5. Restart Obsidian
6. Go to Settings → Community Plugins
7. Enable "Conspiracy Board Graph"

### Method 2: Build from Source

```bash
# Clone the repository
git clone https://github.com/yourusername/conspiracy-board-graph.git

# Navigate to the plugin directory
cd conspiracy-board-graph

# Install dependencies
npm install

# Build the plugin
npm run build

# Copy to your vault
cp main.js manifest.json styles.css /path/to/your/vault/.obsidian/plugins/conspiracy-board-graph/
```

### Building the TypeScript

To compile `main.ts` to `main.js`, you'll need to set up a TypeScript build process:

1. Install dependencies:
```bash
npm init -y
npm install --save-dev @types/node typescript obsidian
```

2. Create `tsconfig.json`:
```json
{
  "compilerOptions": {
    "target": "ES6",
    "module": "CommonJS",
    "lib": ["ES2015", "DOM"],
    "outDir": ".",
    "rootDir": ".",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["main.ts"]
}
```

3. Build:
```bash
npx tsc
```

## 🎮 Usage

### Opening the Conspiracy Board

**Option 1: Ribbon Icon**
- Click the 📌 pin icon in the left sidebar

**Option 2: Command Palette**
- Press `Ctrl/Cmd + P`
- Type "Open Conspiracy Board"
- Press Enter

**Option 3: Right-click**
- Right-click on any pane
- Select "Open Conspiracy Board"

### Folder Mode

The conspiracy board shows notes from your **current folder** by default!

**Header Display:**
- 📍 Shows your current folder path
- **📁 Current Folder** button - Click to toggle between folder and all files

**How it works:**
1. Navigate to any folder in your vault (click a folder in file explorer)
2. Open the conspiracy board
3. You'll see only notes from that folder!
4. Click **📁 Current Folder** to switch to **📂 All Files** mode
5. The board auto-updates when you navigate to different folders

### Interacting with the Board

- **Drag Notes**: Click and drag any sticky note or polaroid to reposition it - stays where you put it!
- **Open Files**: Double-click on any note to open that file
- **View Links**: Red strings show connections between your notes
- **Static Layout**: Notes stay pinned in place like real sticky notes on a cork board
- **Manual Organization**: Arrange your notes however you like - they won't move on their own
- **Switch Modes**: Toggle between current folder and all files

### What You'll See

- **Text Files**: Display as yellow/cream sticky notes with handwritten text
- **Image Files**: Appear as polaroid-style instant photos (.png, .jpg, .jpeg, .gif, .webp)
- **Connections**: Red strings that droop naturally between linked notes
- **Pins**: Metallic push pins at each connection point and on each note
- **Cork Board**: Realistic cork texture background
- **Current Folder**: Displayed at the top with 📍 icon

## 🎨 Customization

You can customize the appearance by editing the source files:

### Change Sticky Note Colors
Edit `main.ts` around line 175 where nodes are created:
```typescript
color: ['#fef08a', '#fde047', '#fcd34d'][Math.floor(Math.random() * 3)]
// Add your own hex colors to the array
```

### Change Red String Color
Edit `main.ts` in the `drawRedString` function:
```typescript
ctx.strokeStyle = '#dc2626'; // Change to any color
```

### Adjust Cork Board Color
Edit `styles.css`:
```css
.conspiracy-board-container {
    background-color: #8b6f47; /* Your cork color */
}
```

### Modify Initial Layout
Edit the `loadVaultData` function in `main.ts`:
```typescript
const spacing = 180;  // Distance between notes
```

Change spacing to spread notes further apart or closer together.

### Change Fonts
The plugin uses:
- **Permanent Marker** for sticky note handwriting
- **Special Elite** for typewriter effects

Change these in `styles.css` line 4 or in the drawing functions.

## 🔧 Compatibility

- **Obsidian Version**: 0.15.0 or higher
- **Desktop**: ✅ Fully supported
- **Mobile**: ✅ Supported (with responsive adjustments)
- **Themes**: Works with both light and dark themes

## 🐛 Troubleshooting

### Plugin doesn't activate
- Make sure all files are in the correct folder
- Check that the plugin is enabled in Settings → Community Plugins
- Try restarting Obsidian

### Fonts don't load
- Check your internet connection (fonts load from Google Fonts)
- If offline, the plugin will fall back to system fonts

### Performance issues
- The conspiracy board effect is canvas-intensive
- For large graphs (500+ nodes), you may experience slower rendering
- Consider using filters to reduce visible nodes

### Red strings don't appear
- This is a known limitation with some Obsidian graph implementations
- Try toggling the plugin off and on
- Check the developer console for errors (Ctrl/Cmd + Shift + I)

## 🎯 Roadmap

Future enhancements planned:

- [ ] Zoom and pan controls
- [ ] Search/filter notes
- [ ] Right-click context menu for nodes
- [ ] Save/load custom board layouts
- [ ] Custom pin colors for different note types
- [ ] Tags displayed as different colored sticky notes
- [ ] Load actual image files into polaroids
- [ ] Add text annotations/arrows
- [ ] Export board as high-res image
- [ ] Multiple boards for different topics
- [ ] Collaboration features (shared boards)
- [ ] Timeline view (organize by date)
- [ ] Custom background images
- [ ] Tape and clip alternatives to pins
- [ ] Undo/redo for layout changes

## 🤝 Contributing

Contributions are welcome! Feel free to:

- Report bugs
- Suggest features
- Submit pull requests
- Share your customized conspiracy boards

## 📄 License

MIT License - feel free to use and modify as you wish!

## 🙏 Credits

- Inspired by detective TV shows and true crime documentaries
- Built with love for the Obsidian community
- Fonts: Google Fonts (Permanent Marker, Special Elite, Shadows Into Light)

## 📸 Screenshots

*Add screenshots of your conspiracy board in action here!*

### Before (Standard Graph View)
Standard Obsidian graph with default styling

### After (Conspiracy Board)
Cork board background with red strings, sticky notes, polaroids, and pins

---

**Made with 🔴 for obsessive note-takers and conspiracy theorists everywhere**

*"Connect the dots. Find the truth."*
