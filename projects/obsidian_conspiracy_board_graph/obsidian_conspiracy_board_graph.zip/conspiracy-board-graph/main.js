"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const obsidian_1 = require("obsidian");
const VIEW_TYPE_CONSPIRACY_BOARD = 'conspiracy-board-view';
class ConspiracyBoardPlugin extends obsidian_1.Plugin {
    onload() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('Loading Conspiracy Board Graph plugin');
            // Register the conspiracy board view
            this.registerView(VIEW_TYPE_CONSPIRACY_BOARD, (leaf) => new ConspiracyBoardView(leaf));
            // Add ribbon icon to open conspiracy board
            this.addRibbonIcon('pin', 'Open Conspiracy Board', () => {
                this.activateView();
            });
            // Add command to open conspiracy board
            this.addCommand({
                id: 'open-conspiracy-board',
                name: 'Open Conspiracy Board',
                callback: () => {
                    this.activateView();
                }
            });
        });
    }
    activateView() {
        return __awaiter(this, void 0, void 0, function* () {
            const { workspace } = this.app;
            let leaf = null;
            const leaves = workspace.getLeavesOfType(VIEW_TYPE_CONSPIRACY_BOARD);
            if (leaves.length > 0) {
                // View already exists, focus it
                leaf = leaves[0];
            }
            else {
                // Create new view in right sidebar or main area
                leaf = workspace.getRightLeaf(false);
                if (leaf) {
                    yield leaf.setViewState({
                        type: VIEW_TYPE_CONSPIRACY_BOARD,
                        active: true,
                    });
                }
            }
            if (leaf) {
                workspace.revealLeaf(leaf);
            }
        });
    }
    onunload() {
        console.log('Unloading Conspiracy Board Graph plugin');
    }
}
exports.default = ConspiracyBoardPlugin;
class ConspiracyBoardView extends obsidian_1.ItemView {
    constructor(leaf) {
        super(leaf);
        this.nodes = [];
        this.edges = [];
        // Interaction state
        this.isDragging = false;
        this.draggedNode = null;
        this.offsetX = 0;
        this.offsetY = 0;
        this.scale = 1;
        this.panX = 0;
        this.panY = 0;
        // Folder tracking
        this.currentFolder = '/';
        this.showAllFiles = false;
        // UI elements
        this.folderLabel = null;
        this.toggleButton = null;
    }
    getViewType() {
        return VIEW_TYPE_CONSPIRACY_BOARD;
    }
    getDisplayText() {
        return 'Conspiracy Board';
    }
    getIcon() {
        return 'pin';
    }
    onOpen() {
        return __awaiter(this, void 0, void 0, function* () {
            const container = this.containerEl.children[1];
            container.empty();
            container.addClass('conspiracy-board-container');
            // Create header with folder info and controls
            const header = container.createEl('div', {
                cls: 'conspiracy-board-header'
            });
            this.folderLabel = header.createEl('div', {
                cls: 'conspiracy-board-folder-label',
                text: 'Loading...'
            });
            this.toggleButton = header.createEl('button', {
                cls: 'conspiracy-board-toggle',
                text: '📁 Current Folder'
            });
            this.toggleButton.addEventListener('click', () => {
                this.showAllFiles = !this.showAllFiles;
                this.toggleButton.setText(this.showAllFiles ? '📂 All Files' : '📁 Current Folder');
                this.reloadData();
            });
            // Create canvas
            this.canvas = container.createEl('canvas', {
                cls: 'conspiracy-board-canvas'
            });
            const ctx = this.canvas.getContext('2d');
            if (!ctx) {
                console.error('Failed to get canvas context');
                return;
            }
            this.ctx = ctx;
            console.log('Canvas initialized');
            // Set canvas size
            this.resizeCanvas();
            // Also resize after a short delay to ensure DOM is ready
            setTimeout(() => {
                this.resizeCanvas();
            }, 100);
            window.addEventListener('resize', this.resizeCanvas.bind(this));
            // Detect current folder
            this.updateCurrentFolder();
            // Load vault data
            yield this.loadVaultData();
            // Force an initial render
            console.log('Initial render with', this.nodes.length, 'nodes');
            this.render();
            // Set up interactions
            this.setupInteractions();
            // Start animation loop
            this.startAnimation();
            // Listen for file navigation changes
            this.registerEvent(this.app.workspace.on('active-leaf-change', () => {
                this.updateCurrentFolder();
                this.reloadData();
            }));
            // Listen for file explorer folder changes
            this.registerEvent(this.app.workspace.on('file-open', () => {
                this.updateCurrentFolder();
                this.reloadData();
            }));
        });
    }
    updateCurrentFolder() {
        // Get active file
        const activeFile = this.app.workspace.getActiveFile();
        if (activeFile) {
            // Get folder from active file
            const folder = activeFile.parent;
            this.currentFolder = folder ? folder.path : '/';
        }
        else {
            // Try to get from file explorer
            const fileExplorer = this.app.workspace.getLeavesOfType('file-explorer')[0];
            if (fileExplorer && fileExplorer.view.file) {
                const explorerFile = fileExplorer.view.file;
                this.currentFolder = explorerFile.path || '/';
            }
            else {
                this.currentFolder = '/';
            }
        }
        // Update label
        if (this.folderLabel) {
            const displayPath = this.currentFolder === '/' ? 'Root' : this.currentFolder;
            this.folderLabel.setText(`📍 ${displayPath}`);
        }
        console.log('Current folder:', this.currentFolder);
    }
    reloadData() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.loadVaultData();
        });
    }
    resizeCanvas() {
        const container = this.containerEl.children[1];
        const canvasContainer = container.querySelector('.conspiracy-board-canvas');
        if (!canvasContainer) {
            console.error('Canvas container not found');
            return;
        }
        // Get actual dimensions
        const rect = canvasContainer.getBoundingClientRect();
        this.canvas.width = rect.width || 800;
        this.canvas.height = rect.height || 600;
        console.log('Canvas resized to:', this.canvas.width, 'x', this.canvas.height);
        this.render();
    }
    loadVaultData() {
        return __awaiter(this, void 0, void 0, function* () {
            let files = this.app.vault.getMarkdownFiles();
            console.log('Total files in vault:', files.length);
            // Filter by current folder if not showing all files
            if (!this.showAllFiles && this.currentFolder !== '/') {
                const beforeFilter = files.length;
                files = files.filter(file => {
                    var _a;
                    // Check if file is in current folder or subfolders
                    return file.path.startsWith(this.currentFolder + '/') ||
                        ((_a = file.parent) === null || _a === void 0 ? void 0 : _a.path) === this.currentFolder;
                });
                console.log(`Filtered from ${beforeFilter} to ${files.length} files in folder: ${this.currentFolder}`);
                // If no files in current folder, fall back to all files
                if (files.length === 0) {
                    console.log('No files in current folder, showing all files');
                    files = this.app.vault.getMarkdownFiles();
                    this.showAllFiles = true;
                    if (this.toggleButton) {
                        this.toggleButton.setText('📂 All Files');
                    }
                }
            }
            // Limit to first 50 files for performance
            const displayFiles = files.slice(0, 50);
            const filePathSet = new Set(displayFiles.map(f => f.path));
            console.log(`Loading conspiracy board with ${displayFiles.length} files from ${this.showAllFiles ? 'all folders' : this.currentFolder}`);
            // Create nodes first
            this.nodes = displayFiles.map((file, i) => {
                // Spread nodes in a grid pattern for better initial layout
                const cols = Math.ceil(Math.sqrt(displayFiles.length));
                const row = Math.floor(i / cols);
                const col = i % cols;
                const spacing = 180;
                const offsetX = (this.canvas.width - (cols * spacing)) / 2;
                const offsetY = (this.canvas.height - (Math.ceil(displayFiles.length / cols) * spacing)) / 2;
                return {
                    id: file.path,
                    name: file.basename,
                    x: offsetX + col * spacing + spacing / 2,
                    y: offsetY + row * spacing + spacing / 2,
                    isImage: file.extension.match(/(png|jpg|jpeg|gif|webp)$/i) !== null,
                    rotation: (Math.random() - 0.5) * 0.15,
                    color: ['#fef08a', '#fde047', '#fcd34d'][Math.floor(Math.random() * 3)]
                };
            });
            // Build edges from links
            this.edges = [];
            for (const file of displayFiles) {
                const cache = this.app.metadataCache.getFileCache(file);
                if (!cache || !cache.links)
                    continue;
                // Get outgoing links
                for (const link of cache.links) {
                    const linkedFile = this.app.metadataCache.getFirstLinkpathDest(link.link, file.path);
                    if (linkedFile && filePathSet.has(linkedFile.path)) {
                        // Both files are in our display set
                        this.edges.push({
                            source: file.path,
                            target: linkedFile.path
                        });
                    }
                }
            }
            console.log('Created', this.nodes.length, 'nodes and', this.edges.length, 'edges');
        });
    }
    setupInteractions() {
        // Mouse down - start dragging
        this.canvas.addEventListener('mousedown', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const x = (e.clientX - rect.left - this.panX) / this.scale;
            const y = (e.clientY - rect.top - this.panY) / this.scale;
            // Find clicked node
            for (const node of this.nodes) {
                const dx = x - node.x;
                const dy = y - node.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                if (distance < 60) {
                    this.isDragging = true;
                    this.draggedNode = node;
                    this.offsetX = dx;
                    this.offsetY = dy;
                    this.canvas.style.cursor = 'grabbing';
                    break;
                }
            }
        });
        // Mouse move - drag node
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const x = (e.clientX - rect.left - this.panX) / this.scale;
            const y = (e.clientY - rect.top - this.panY) / this.scale;
            if (this.isDragging && this.draggedNode) {
                this.draggedNode.x = x - this.offsetX;
                this.draggedNode.y = y - this.offsetY;
                this.render(); // Render while dragging
            }
            else {
                // Check if hovering over node
                let hovering = false;
                for (const node of this.nodes) {
                    const dx = x - node.x;
                    const dy = y - node.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < 60) {
                        hovering = true;
                        break;
                    }
                }
                this.canvas.style.cursor = hovering ? 'grab' : 'default';
            }
        });
        // Mouse up - stop dragging
        this.canvas.addEventListener('mouseup', () => {
            this.isDragging = false;
            this.draggedNode = null;
            this.canvas.style.cursor = 'default';
            this.render(); // Final render after dragging
        });
        // Double click - open file
        this.canvas.addEventListener('dblclick', (e) => __awaiter(this, void 0, void 0, function* () {
            const rect = this.canvas.getBoundingClientRect();
            const x = (e.clientX - rect.left - this.panX) / this.scale;
            const y = (e.clientY - rect.top - this.panY) / this.scale;
            for (const node of this.nodes) {
                const dx = x - node.x;
                const dy = y - node.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                if (distance < 60) {
                    const file = this.app.vault.getAbstractFileByPath(node.id);
                    if (file instanceof obsidian_1.TFile) {
                        yield this.app.workspace.getLeaf().openFile(file);
                    }
                    break;
                }
            }
        }));
    }
    startAnimation() {
        // Only render when needed (no continuous animation)
        this.render();
    }
    updatePhysics() {
        // Physics disabled - notes stay where they're placed
        // Only update when manually dragging
    }
    render() {
        if (!this.ctx || !this.canvas) {
            console.error('Canvas or context not initialized');
            return;
        }
        const ctx = this.ctx;
        console.log('Rendering:', this.nodes.length, 'nodes,', this.edges.length, 'edges');
        // Clear canvas with cork background color
        ctx.fillStyle = '#8b6f47';
        ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        ctx.save();
        ctx.translate(this.panX, this.panY);
        ctx.scale(this.scale, this.scale);
        // Draw edges (red strings) FIRST so they appear behind nodes
        ctx.save();
        for (const edge of this.edges) {
            const source = this.nodes.find(n => n.id === edge.source);
            const target = this.nodes.find(n => n.id === edge.target);
            if (!source || !target)
                continue;
            drawRedString(ctx, source.x, source.y, target.x, target.y);
        }
        ctx.restore();
        // Draw nodes on top
        ctx.save();
        for (const node of this.nodes) {
            if (node.isImage) {
                drawPolaroid(ctx, node.x, node.y, node.name, node.rotation);
            }
            else {
                drawStickyNote(ctx, node.x, node.y, node.name, node.rotation, node.color);
            }
            // Pin on top
            drawPin(ctx, node.x, node.y - 50);
        }
        ctx.restore();
        ctx.restore();
        // Debug info
        if (this.nodes.length === 0) {
            ctx.fillStyle = '#fef3c7';
            ctx.font = '16px "Special Elite", monospace';
            ctx.fillText('No notes found in current folder!', 20, 40);
            ctx.fillText('Try toggling to "All Files" mode or navigate to a folder with notes.', 20, 65);
        }
        else if (this.edges.length === 0) {
            ctx.fillStyle = '#fef3c7';
            ctx.font = '14px "Special Elite", monospace';
            ctx.fillText('No connections found. Try linking some notes!', 20, 30);
        }
    }
    onClose() {
        return __awaiter(this, void 0, void 0, function* () {
            window.removeEventListener('resize', this.resizeCanvas.bind(this));
        });
    }
}
// Helper function to draw a drawing pin
function drawPin(ctx, x, y) {
    ctx.save();
    // Pin shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
    ctx.shadowBlur = 3;
    ctx.shadowOffsetX = 1;
    ctx.shadowOffsetY = 2;
    // Pin head (metallic looking)
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, 6);
    gradient.addColorStop(0, '#e5e7eb');
    gradient.addColorStop(0.5, '#9ca3af');
    gradient.addColorStop(1, '#6b7280');
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, 6, 0, Math.PI * 2);
    ctx.fill();
    // Pin highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.beginPath();
    ctx.arc(x - 1.5, y - 1.5, 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}
// Helper function to draw red string
function drawRedString(ctx, x1, y1, x2, y2) {
    ctx.save();
    ctx.strokeStyle = '#dc2626';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 4;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;
    // Calculate control point for bezier curve (creates drooping effect)
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;
    const distance = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    const droop = distance * 0.08;
    ctx.beginPath();
    ctx.moveTo(x1, y1 - 50); // Start from pin position
    ctx.quadraticCurveTo(midX, midY + droop, x2, y2 - 50); // End at pin position
    ctx.stroke();
    ctx.restore();
}
// Helper function to draw a polaroid photo
function drawPolaroid(ctx, x, y, text, rotation) {
    ctx.save();
    const width = 100;
    const height = 120;
    ctx.translate(x, y);
    ctx.rotate(rotation);
    // Polaroid shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetX = 3;
    ctx.shadowOffsetY = 3;
    // Polaroid border (white)
    ctx.fillStyle = '#fefefe';
    ctx.fillRect(-width / 2, -height / 2, width, height);
    // Photo area (placeholder)
    ctx.shadowColor = 'transparent';
    ctx.fillStyle = '#d1d5db';
    ctx.fillRect(-width / 2 + 5, -height / 2 + 5, width - 10, height - 35);
    // Text label at bottom
    ctx.fillStyle = '#374151';
    ctx.font = '10px "Courier New", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(text.substring(0, 12), 0, height / 2 - 10);
    ctx.restore();
}
// Helper function to draw a sticky note
function drawStickyNote(ctx, x, y, text, rotation, color) {
    ctx.save();
    const width = 120;
    const height = 100;
    ctx.translate(x, y);
    ctx.rotate(rotation);
    // Sticky note shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 3;
    ctx.fillStyle = color;
    ctx.fillRect(-width / 2, -height / 2, width, height);
    // Slight paper texture (lines)
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.03)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(-width / 2, -height / 2 + i * 20 + 10);
        ctx.lineTo(width / 2, -height / 2 + i * 20 + 10);
        ctx.stroke();
    }
    // Text
    ctx.fillStyle = '#1f2937';
    ctx.font = '12px "Permanent Marker", cursive';
    ctx.textAlign = 'center';
    // Word wrap text
    const words = text.split(' ');
    let line = '';
    let yOffset = -height / 2 + 25;
    const maxLines = 4;
    let lineCount = 0;
    for (let i = 0; i < words.length && lineCount < maxLines; i++) {
        const testLine = line + words[i] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > width - 20 && i > 0) {
            ctx.fillText(line, 0, yOffset);
            line = words[i] + ' ';
            yOffset += 18;
            lineCount++;
        }
        else {
            line = testLine;
        }
    }
    if (lineCount < maxLines && line.trim()) {
        ctx.fillText(line, 0, yOffset);
    }
    ctx.restore();
}
