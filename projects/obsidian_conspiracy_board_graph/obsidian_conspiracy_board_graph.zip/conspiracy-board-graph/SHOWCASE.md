# Conspiracy Board View - Visual Showcase

## What It Looks Like

```
┌─────────────────────────────────────────────────────────────┐
│  📌 Conspiracy Board                               ⚙️ ✕     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│         🪵 🪵 🪵  CORK BOARD TEXTURE  🪵 🪵 🪵              │
│                                                             │
│    📌                    📌                    📌           │
│   ┌──────┐   🔴────────┐          ┐   🔴────┌──────┐        │
│   │ TODO │──🔴────────→│  Project │  ────→  │ Notes│        │
│   │ List │             │   Plan   │   🔴    │ 2024 │        │
│   └──────┘             └──────────┘   │     └──────┘        │
│   (yellow                (cream)       │     (yellow)        │
│    sticky)                             │                     │
│                                        │                     │
│      📌                                ↓                     │
│     ┌─────────┐          📌       ┌────────┐                │
│     │ Image   │                   │ Ideas  │                │
│     │ [photo] │   🔴──────────────│ Brainstorm              │
│     │ _______ │                   └────────┘                │
│     └─────────┘                   (yellow)                  │
│     (polaroid)                                               │
│                          📌                                  │
│                     ┌─────────┐                              │
│                     │ Research│                              │
│                     │ Article │                              │
│                     └─────────┘                              │
│                     (cream)                                  │
└─────────────────────────────────────────────────────────────┘
```

## Key Visual Elements

### 1. Cork Board Background
- Warm brown color (#8b6f47)
- Subtle grain texture
- Organic noise patterns
- Gentle vignette at edges
- Darker in dark mode

### 2. Sticky Notes (Text Files)
**Appearance:**
- Size: 120px × 100px
- Colors: Yellow (#fef08a), Cream (#fde047), Light Yellow (#fcd34d)
- Slight random rotation (-6° to +6°)
- Drop shadow for depth
- Faint ruled lines
- Text in "Permanent Marker" font

**Content:**
- File name displayed
- Word-wrapped text
- Max 4 lines visible
- Centered text

### 3. Polaroid Photos (Image Files)
**Appearance:**
- Size: 100px × 120px
- White border (#fefefe)
- Photo area: Gray placeholder (#d1d5db)
- Bottom caption area
- Slight random rotation
- Stronger drop shadow

**Content:**
- Filename in "Courier New" font
- Up to 12 characters shown
- Centered at bottom

### 4. Red String (Connections)
**Appearance:**
- Color: Red (#dc2626)
- Width: 2px
- Drooping bezier curves
- Shadow: Black with blur
- Natural sagging based on distance

**Physics:**
- Longer connections = more droop
- 8% droop factor
- Smooth curves

### 5. Drawing Pins
**Appearance:**
- Size: 6px radius circle
- Metallic gradient (silver/gray)
- White highlight on top-left
- Drop shadow
- Placed at:
  - Each string endpoint
  - Top center of each note

**Style:**
- Realistic metallic look
- Gradient from light to dark gray
- Small white highlight for shine

## Color Palette

### Cork Board
- **Base**: #8b6f47 (Medium brown)
- **Variations**: #9b7e54, #a68968, #654437
- **Texture overlays**: rgba(139, 111, 71, 0.1)

### Sticky Notes
- **Yellow**: #fef08a
- **Cream**: #fde047
- **Light Yellow**: #fcd34d
- **Text**: #1f2937 (dark gray)

### Polaroids
- **Border**: #fefefe (white)
- **Photo area**: #d1d5db (light gray)
- **Text**: #374151 (gray)

### Strings & Pins
- **String**: #dc2626 (red)
- **Pin gradient**: #e5e7eb → #9ca3af → #6b7280
- **Pin highlight**: rgba(255, 255, 255, 0.6)

## Typography

### Sticky Notes
- **Font**: "Permanent Marker", cursive
- **Size**: 12px
- **Color**: #1f2937
- **Style**: Handwritten, casual

### Polaroids
- **Font**: "Courier New", monospace
- **Size**: 10px
- **Color**: #374151
- **Style**: Typewriter

### View Header
- **Font**: "Special Elite", monospace
- **Color**: #fef3c7 (cream)
- **Style**: Vintage typewriter

## Interactions

### Drag
- **Cursor**: Grab (open hand) on hover
- **Cursor**: Grabbing (closed fist) when dragging
- **Effect**: Note follows mouse
- **Physics**: Velocity resets to zero

### Double-Click
- **Action**: Opens the file in Obsidian
- **Target**: Any note (sticky or polaroid)

### Auto-Layout
- **Repulsion**: Notes push away from each other
- **Attraction**: Connected notes pull together
- **Damping**: Smooth movement
- **Result**: Self-organizing constellation

## Layout Behavior

### Force-Directed Physics
1. **Repulsion Force**: 3000 (notes push apart)
2. **Attraction Force**: 0.001 (connected notes pull together)
3. **Damping**: 0.9 (smooths movement)
4. **Initial**: Circular arrangement
5. **Final**: Organic, balanced layout

### Performance
- 60 FPS rendering
- Canvas-based drawing
- Efficient physics updates
- Limited to 50 nodes (configurable)

## Responsive Design

### Desktop
- Full features
- Smooth animations
- All interactions

### Mobile
- Scaled-down textures
- Touch support
- Same features

### Dark Mode
- Darker cork (#5a4a36)
- Reduced brightness
- Same structure

## Export Quality
- High-resolution canvas
- Print-friendly
- Maintains aspect ratio
- Cork texture visible

---

**Perfect for:** Mind mapping, project planning, research organization, creative brainstorming, detective roleplay, visual thinking, knowledge management
