import { Plugin, WorkspaceLeaf, TFile, PluginSettingTab, Setting } from 'obsidian';
import { CorkboardView, VIEW_TYPE_CORKBOARD } from './corkboard-view';

interface CorkboardSettings {
    customBackgroundUrl: string;
    useCustomBackground: boolean;
}

const DEFAULT_SETTINGS: CorkboardSettings = {
    customBackgroundUrl: '',
    useCustomBackground: false
}

export default class CorkboardPlugin extends Plugin {
    settings: CorkboardSettings;

    async onload() {
        console.log('Loading Corkboard plugin');

        // Load settings
        await this.loadSettings();

        // Register the corkboard view
        this.registerView(
            VIEW_TYPE_CORKBOARD,
            (leaf) => new CorkboardView(leaf, this)
        );

        // Add settings tab
        this.addSettingTab(new CorkboardSettingTab(this.app, this));

        // Add ribbon icon to open corkboard
        this.addRibbonIcon('layout-grid', 'Open Corkboard', () => {
            this.activateCorkboardView();
        });

        // Add command to open corkboard
        this.addCommand({
            id: 'open-corkboard-view',
            name: 'Open Corkboard',
            callback: () => {
                this.activateCorkboardView();
            }
        });

        // Add command to add current folder to corkboard
        this.addCommand({
            id: 'show-folder-in-corkboard',
            name: 'Show current folder in Corkboard',
            callback: () => {
                const activeFile = this.app.workspace.getActiveFile();
                if (activeFile) {
                    const folder = activeFile.parent;
                    this.activateCorkboardView(folder?.path);
                }
            }
        });
    }

    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }

    async saveSettings() {
        await this.saveData(this.settings);
        
        // Update all open corkboard views
        const leaves = this.app.workspace.getLeavesOfType(VIEW_TYPE_CORKBOARD);
        leaves.forEach(leaf => {
            if (leaf.view instanceof CorkboardView) {
                leaf.view.applyCustomBackground();
            }
        });
    }

    async activateCorkboardView(folderPath?: string) {
        const { workspace } = this.app;

        let leaf: WorkspaceLeaf | null = null;
        const leaves = workspace.getLeavesOfType(VIEW_TYPE_CORKBOARD);

        if (leaves.length > 0) {
            // A corkboard view already exists, use it
            leaf = leaves[0];
        } else {
            // Create a new leaf in the right split
            leaf = workspace.getRightLeaf(false);
            if (leaf) {
                await leaf.setViewState({ type: VIEW_TYPE_CORKBOARD, active: true });
            }
        }

        // Reveal the leaf
        if (leaf) {
            workspace.revealLeaf(leaf);
            
            // If a folder path was provided, update the view
            if (folderPath && leaf.view instanceof CorkboardView) {
                leaf.view.setFolder(folderPath);
            }
        }
    }

    onunload() {
        console.log('Unloading Corkboard plugin');
    }
}

class CorkboardSettingTab extends PluginSettingTab {
    plugin: CorkboardPlugin;

    constructor(app: any, plugin: CorkboardPlugin) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display(): void {
        const { containerEl } = this;
        containerEl.empty();

        containerEl.createEl('h2', { text: 'Corkboard Settings' });

        // Use custom background toggle
        new Setting(containerEl)
            .setName('Use custom background')
            .setDesc('Enable to use a custom background image instead of the default cork texture')
            .addToggle(toggle => toggle
                .setValue(this.plugin.settings.useCustomBackground)
                .onChange(async (value) => {
                    this.plugin.settings.useCustomBackground = value;
                    await this.plugin.saveSettings();
                }));

        // Custom background URL
        new Setting(containerEl)
            .setName('Custom background URL')
            .setDesc('Enter a URL to an image to use as the corkboard background (works best with seamless textures)')
            .addText(text => text
                .setPlaceholder('https://example.com/image.jpg')
                .setValue(this.plugin.settings.customBackgroundUrl)
                .onChange(async (value) => {
                    this.plugin.settings.customBackgroundUrl = value;
                    await this.plugin.saveSettings();
                }));

        containerEl.createEl('p', { 
            text: '💡 Tip: For best results, use a seamless tileable texture image.',
            cls: 'setting-item-description'
        });
    }
}
