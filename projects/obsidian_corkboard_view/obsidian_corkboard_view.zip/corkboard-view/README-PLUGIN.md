# Corkboard View - Obsidian Plugin

A beautifully designed Obsidian plugin that recreates Scrivener's iconic Corkboard feature, displaying your notes as visual index cards that you can arrange and organize.

![Corkboard View](https://img.shields.io/badge/obsidian-plugin-purple) ![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?logo=typescript&logoColor=white)

## ✨ Features

### Visual Organization
- **Auto-Follow Current Folder**: Automatically displays cards from the folder of your currently selected file or folder
- **Smooth Updates**: Cards fade smoothly when switching folders without losing the background
- **Index Card Display**: View your notes as clean, professional index cards on a realistic cork-textured board
- **Drag & Drop**: Intuitively reorder cards by dragging them around the board
- **Manual Folder Selection**: Optionally choose any folder or view all notes in your vault
- **Clean Aesthetics**: Straight, aligned cards for a professional, organized appearance

### Card Information
- **Smart Titles**: Automatically extracts note titles from first heading or filename
- **Content Previews**: Shows the first few lines of each note as a synopsis
- **Metadata Display**: View word count and last modified time on each card
- **Clean Design**: Professional, distraction-free card layout

### Refined Design
- **Realistic Cork Texture**: SVG-generated cork background with authentic grain and variation
- **Custom Background Support**: Use your own background image via plugin settings
- **Editorial Typography**: Uses beautiful serif fonts (Crimson Pro, Newsreader) for a literary feel
- **Sleek Header**: Compact, minimal header that maximizes content space
- **Smooth Animations**: Clean fade-in effects without rotation
- **Dark Mode Support**: Fully styled for both light and dark themes
- **Responsive Layout**: Adapts beautifully to different screen sizes
- **Custom Scrollbars**: Cork-themed scrolling experience

## ⚙️ Settings

Access settings via Settings → Corkboard View:

### Custom Background
- **Use custom background**: Toggle to enable/disable custom background images
- **Custom background URL**: Enter a URL to any image to replace the default cork texture
- Works with any image URL (best results with seamless, tileable textures)
- Changes apply immediately to all open corkboard views

**Finding Background Images:**
- Search for "seamless cork texture" or "tileable wood texture"
- Try sites like Unsplash, Pexels, or texture libraries
- Direct image URLs work best (ending in .jpg, .png, etc.)

## 🚀 Installation

### Method 1: Quick Install (Recommended - No Build Required!)

The plugin includes pre-compiled JavaScript files, so you can use it immediately without Node.js or building.

1. **Navigate to your vault's plugins folder:**
   ```
   <your-vault>/.obsidian/plugins/
   ```

2. **Create a new folder:**
   ```
   corkboard-view/
   ```

3. **Copy these files into the folder:**
   - `main.js` ✅ (pre-compiled, all code bundled)
   - `manifest.json`
   - `styles.css`

4. **Reload Obsidian** or restart the app

5. **Enable the plugin:**
   - Open Settings → Community Plugins
   - Find "Corkboard View" and toggle it on

### Method 2: Build from TypeScript Source

If you want to modify the plugin or build from the TypeScript source files:

1. **Clone or download this repository**

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Build the plugin:**
   ```bash
   npm run build
   ```

4. **Copy the build files** to your vault's plugin folder as described above

**Note:** The repository includes both TypeScript source files (`.ts`) and pre-compiled JavaScript files (`.js`), so you can choose either method.

## 📖 Usage

### Opening the Corkboard

There are three ways to open the Corkboard view:

1. **Ribbon Icon**: Click the grid icon in the left sidebar
2. **Command Palette**: Open command palette (Ctrl/Cmd + P) and search for "Open Corkboard"
3. **Folder Context**: Use "Show current folder in Corkboard" command to view the current note's folder

### Auto-Following Folders

**The corkboard automatically follows your current folder!** When you:
- Open the corkboard, it shows cards from the folder of your currently active file
- Switch to a different file in the file explorer, the corkboard automatically updates to show that folder's cards
- Click on a folder in the file explorer (without opening a file), the corkboard shows that folder's cards
- Navigate between different folders, the corkboard follows along with smooth fade transitions

This makes it perfect for staying focused on your current project or topic.

### Working with Cards

#### Viewing Notes
- **Click any card** to open that note in the editor
- **Right-click a card** for additional options:
  - Open
  - Open in new tab
  - Delete

#### Organizing Cards
- **Drag cards** to rearrange their order
- Cards will maintain their positions until you refresh or change folders

#### Manual Folder Selection (Optional)
- Click the **"Select Folder"** button in the header to override auto-follow
- Choose any folder from your vault
- Select "/" or "Root" to view all notes
- The corkboard will resume auto-following when you click "Refresh"

#### Refreshing
- Click the **"Refresh"** button to reload cards from your current folder
- This also resumes auto-following if you had manually selected a different folder
- Useful after creating, editing, or deleting notes

### Header Information

The corkboard header shows:
- **Current Folder**: The folder being displayed with a 📁 icon
- If showing all notes, displays "📁 All Notes"
- Updates automatically as you navigate between files

### Card Information

Each card displays:
- **Title**: First heading in the note or filename
- **Excerpt**: First few lines of content (up to 180 characters)
- **Word Count**: Total words in the note (✎ icon)
- **Last Modified**: Relative time since last edit (◷ icon)

## 🎨 Customization

### Custom Background (Easy Way)

Use the plugin settings (Settings → Corkboard View) to easily set a custom background image without editing any code!

### Modifying the Aesthetic (Advanced)

For advanced customization, the plugin uses CSS variables. Edit `styles.css`:

```css
:root {
    --cork-bg: #d8b896;        /* Cork background color */
    --card-bg: #fffef9;        /* Card background */
    --text-primary: #1a1613;   /* Main text color */
    --border-color: #e8dcc8;   /* Card borders */
    /* ... more variables */
}
```

### Changing Typography

The plugin uses Google Fonts. To use different fonts, update the import and font-family declarations in `styles.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Your+Font&display=swap');

.card-title {
    font-family: 'Your Font', serif;
}
```

### Adjusting Card Size

Modify the grid template in `styles.css`:

```css
.corkboard-grid {
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    /* Change 260px to your preferred minimum card width */
}
```

## 🛠️ Development

### Project Structure

```
corkboard-view/
├── main.ts                 # TypeScript source - Plugin entry point
├── main.js                 # ✅ Compiled & bundled JavaScript (ready to use!)
├── corkboard-view.ts       # TypeScript source - View logic
├── styles.css              # All styling
├── manifest.json           # Plugin metadata
├── package.json            # Dependencies
├── tsconfig.json           # TypeScript config
├── esbuild.config.mjs      # Build configuration
├── README-PLUGIN.md        # Full documentation
└── QUICKSTART.md           # Quick installation guide
```

**Note:** The `main.js` file contains all the bundled code from both TypeScript files, so you don't need separate module files.

### Building

```bash
# Install dependencies
npm install

# Development build (watch mode)
npm run dev

# Production build
npm run build
```

### TypeScript Structure

**main.ts**: Plugin initialization, ribbon icon, commands
**corkboard-view.ts**: View rendering, card management, drag & drop logic

Both TypeScript files are compiled and bundled into a single `main.js` file for Obsidian.

## 🎯 Roadmap

Potential future enhancements:

- [ ] Persistent card ordering (save positions to metadata)
- [ ] Filtering and sorting options
- [ ] Card color coding by tags
- [ ] Synopsis editing directly on cards
- [ ] Multiple board layouts
- [ ] Export board as image
- [ ] Custom card templates
- [ ] Keyboard navigation

## 🤝 Contributing

Contributions are welcome! Some ways to contribute:

1. **Report bugs**: Open an issue with details
2. **Suggest features**: Share ideas for improvements
3. **Submit PRs**: Code contributions for fixes or new features
4. **Improve docs**: Help make this README better

## 📄 License

MIT License - feel free to use and modify as needed.

## 🙏 Acknowledgments

- Inspired by **Scrivener's Corkboard** feature
- Built for the **Obsidian** community
- Typography by **Google Fonts** (Crimson Pro, Newsreader, DM Mono)

## 💡 Tips

- Use folders to organize different projects or themes
- The corkboard is great for high-level project overviews
- Combine with Obsidian's built-in features like tags and backlinks
- Try dragging cards while planning outlines or story structures
- Perfect for visual thinkers who need to see the big picture

---

**Made with ❤️ for writers, researchers, and visual thinkers**
