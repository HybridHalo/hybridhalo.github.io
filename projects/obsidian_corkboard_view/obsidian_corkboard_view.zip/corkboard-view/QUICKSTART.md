# Quick Start Guide - Corkboard Plugin

## 🚀 Fast Installation (2 minutes)

### Option 1: Use Pre-compiled Files (Easiest!)

The plugin includes both TypeScript source files and pre-compiled JavaScript files, so you can skip the build step!

### Step 1: Copy to Obsidian

1. Find your Obsidian vault's plugins folder:
   - Windows: `C:\Users\YourName\Documents\YourVault\.obsidian\plugins\`
   - Mac: `/Users/YourName/Documents/YourVault/.obsidian/plugins/`
   - Linux: `/home/YourName/Documents/YourVault/.obsidian/plugins/`

2. Create a new folder called `corkboard-view`

3. Copy these 3 files into it:
   - `main.js` ✅ (already compiled, all code bundled!)
   - `styles.css`
   - `manifest.json`

### Step 2: Enable in Obsidian

1. Open Obsidian
2. Go to Settings → Community Plugins
3. Click "Reload plugins" (or restart Obsidian)
4. Find "Corkboard View" and toggle it ON
5. Close settings

### Step 3: Open Corkboard

- Click the grid icon (📊) in the left sidebar, OR
- Press `Ctrl/Cmd + P` and type "Open Corkboard"

---

## Option 2: Build from TypeScript Source (For Developers)

If you want to modify the plugin or build from source:

### Step 1: Install Dependencies
```bash
cd corkboard-plugin
npm install
```

### Step 2: Build the Plugin
```bash
npm run build
```

This will recompile `main.js` and `corkboard-view.js` from the TypeScript source.

---

## 🎯 First Use

1. Open any note in your vault
2. Open the Corkboard (grid icon or Cmd/Ctrl+P → "Open Corkboard")
3. The corkboard automatically shows cards from your current note's folder!
4. Switch to a different file or click on a folder - watch the corkboard smoothly update
5. Try dragging cards around to reorder them
6. Optional: Go to Settings → Corkboard View to set a custom background image

## 💡 Pro Tips

- The corkboard automatically follows folders as you navigate - even when you click folders!
- Updates smoothly with fade transitions - no jarring refreshes
- Customize your background in Settings → Corkboard View
- Right-click cards for more options
- Use "Select Folder" to manually override and view any folder or all notes
- Click "Refresh" to resume auto-following your current folder
- Works great for staying focused on your current project
- Perfect for planning articles, stories, or research projects

## ⚠️ Troubleshooting

**Plugin doesn't appear?**
- Make sure you copied `main.js`, `styles.css`, and `manifest.json` (3 files total)
- Check that files are in `.obsidian/plugins/corkboard-view/`
- Try restarting Obsidian completely

**Cards not showing?**
- Click "Select Folder" and choose a folder with markdown files
- Click "Refresh" button
- Check that you have `.md` files in that folder

**Build fails? (Only if using Option 2)**
- Make sure you have Node.js installed (v16 or higher)
- Delete `node_modules` and run `npm install` again
- Check that all TypeScript files are present

## 📚 Need More Help?

See the full `README-PLUGIN.md` for:
- Detailed feature descriptions
- Customization options
- Development guide
- Contributing guidelines

---

**Enjoy your beautiful corkboard! 📌**
