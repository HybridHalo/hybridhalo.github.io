const { Plugin, ItemView, TFolder, TFile, Menu, Notice, FuzzySuggestModal, PluginSettingTab, Setting } = require('obsidian');

const VIEW_TYPE_CORKBOARD = 'corkboard-view';

// Plugin Settings
class CorkboardSettings {
    constructor() {
        this.customBackgroundUrl = '';
        this.useCustomBackground = false;
    }
}

class CorkboardView extends ItemView {
    constructor(leaf, plugin) {
        super(leaf);
        this.plugin = plugin;
        this.currentFolder = null;
        this.cards = [];
        this.draggedCard = null;
        this.draggedCardIndex = -1;
    }

    getViewType() {
        return VIEW_TYPE_CORKBOARD;
    }

    getDisplayText() {
        return 'Corkboard';
    }

    getIcon() {
        return 'layout-grid';
    }

    async onOpen() {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('corkboard-container');

        // Apply custom background if enabled
        this.applyCustomBackground();

        // Auto-detect and load current folder
        await this.loadCurrentFolder();

        // Register event to update when active file changes
        this.registerEvent(
            this.app.workspace.on('active-leaf-change', async () => {
                await this.loadCurrentFolder();
                this.renderCorkboard();
            })
        );

        // Register event to update when files are opened
        this.registerEvent(
            this.app.workspace.on('file-open', async (file) => {
                if (file) {
                    await this.loadCurrentFolder();
                    this.renderCorkboard();
                }
            })
        );

        this.renderCorkboard();
    }

    applyCustomBackground() {
        const container = this.containerEl.children[1];
        if (this.plugin.settings.useCustomBackground && this.plugin.settings.customBackgroundUrl) {
            container.style.backgroundImage = `url('${this.plugin.settings.customBackgroundUrl}')`;
            container.style.backgroundSize = 'cover';
            container.style.backgroundPosition = 'center';
            container.style.backgroundRepeat = 'no-repeat';
        } else {
            container.style.backgroundImage = '';
            container.style.backgroundSize = '';
            container.style.backgroundPosition = '';
            container.style.backgroundRepeat = '';
        }
    }

    async loadCurrentFolder() {
        // First try to get the active file
        const activeFile = this.app.workspace.getActiveFile();
        
        if (activeFile && activeFile.parent) {
            this.currentFolder = activeFile.parent.path;
        } else {
            // Try to get the active folder from file explorer
            const fileExplorer = this.app.workspace.getLeavesOfType('file-explorer')[0];
            if (fileExplorer && fileExplorer.view) {
                const explorerView = fileExplorer.view;
                // Check if a folder is selected in the file explorer
                if (explorerView.file && explorerView.file instanceof TFolder) {
                    this.currentFolder = explorerView.file.path;
                } else {
                    this.currentFolder = null;
                }
            } else {
                this.currentFolder = null;
            }
        }
        
        await this.loadCards();
    }

    async setFolder(folderPath) {
        this.currentFolder = folderPath;
        await this.loadCards();
        this.renderCorkboard();
    }

    async loadCards() {
        this.cards = [];

        if (!this.currentFolder) {
            // Load all markdown files if no folder specified
            const files = this.app.vault.getMarkdownFiles();
            for (let i = 0; i < files.length; i++) {
                await this.addCard(files[i], i);
            }
        } else {
            // Load files from the specified folder
            const folder = this.app.vault.getAbstractFileByPath(this.currentFolder);
            if (folder && folder instanceof TFolder) {
                const files = folder.children.filter(child => child instanceof TFile && child.extension === 'md');
                for (let i = 0; i < files.length; i++) {
                    await this.addCard(files[i], i);
                }
            }
        }
    }

    async addCard(file, position) {
        const content = await this.app.vault.cachedRead(file);
        const lines = content.split('\n');
        
        // Extract title (first heading or filename)
        let title = file.basename;
        const firstHeading = lines.find(line => line.startsWith('#'));
        if (firstHeading) {
            title = firstHeading.replace(/^#+\s*/, '');
        }

        // Extract excerpt (first non-empty, non-heading line)
        let excerpt = '';
        for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed && !trimmed.startsWith('#') && !trimmed.startsWith('---')) {
                excerpt = trimmed.substring(0, 180);
                break;
            }
        }

        // Calculate word count (approximate)
        const wordCount = content.split(/\s+/).filter(word => word.length > 0).length;

        this.cards.push({
            file: file,
            title: title,
            excerpt: excerpt,
            position: position,
            wordCount: wordCount,
            created: file.stat.ctime,
            modified: file.stat.mtime
        });
    }

    renderCorkboard() {
        const container = this.containerEl.children[1];
        
        // Check if we need to render the header (first time only)
        let header = container.querySelector('.corkboard-header');
        if (!header) {
            container.empty();
            header = this.renderHeader(container);
        } else {
            // Just update the folder path
            this.updateHeaderFolder(header);
        }

        // Update or create the grid
        let grid = container.querySelector('.corkboard-grid');
        if (!grid) {
            grid = container.createDiv({ cls: 'corkboard-grid' });
        }
        
        // Smoothly update cards
        this.updateCards(grid);
    }

    renderHeader(container) {
        const header = container.createDiv({ cls: 'corkboard-header' });
        
        const titleContainer = header.createDiv({ cls: 'corkboard-title-container' });
        titleContainer.createEl('h2', { text: 'Corkboard', cls: 'corkboard-title' });
        
        const folderPath = titleContainer.createSpan({ cls: 'corkboard-folder-path' });
        this.updateFolderPathElement(folderPath);

        const controls = header.createDiv({ cls: 'corkboard-controls' });
        
        // Folder selector button
        const folderBtn = controls.createEl('button', { 
            text: 'Select Folder', 
            cls: 'corkboard-btn' 
        });
        folderBtn.addEventListener('click', () => this.showFolderSelector());

        // Refresh button
        const refreshBtn = controls.createEl('button', { 
            text: 'Refresh', 
            cls: 'corkboard-btn' 
        });
        refreshBtn.addEventListener('click', async () => {
            await this.loadCurrentFolder();
            this.renderCorkboard();
            new Notice('Corkboard refreshed');
        });

        return header;
    }

    updateHeaderFolder(header) {
        const folderPath = header.querySelector('.corkboard-folder-path');
        if (folderPath) {
            this.updateFolderPathElement(folderPath);
        }
    }

    updateFolderPathElement(element) {
        element.empty();
        if (this.currentFolder) {
            element.createSpan({ text: '📁 ', cls: 'folder-icon' });
            element.createSpan({ text: this.currentFolder });
        } else {
            element.setText('📁 All Notes');
        }
    }

    updateCards(grid) {
        // Fade out
        grid.style.opacity = '0';
        grid.style.transition = 'opacity 0.2s ease';

        setTimeout(() => {
            grid.empty();

            if (this.cards.length === 0) {
                const empty = grid.createDiv({ cls: 'corkboard-empty' });
                empty.createEl('p', { text: 'No notes to display' });
                empty.createEl('p', { text: 'Select a folder or create some notes!', cls: 'corkboard-empty-hint' });
            } else {
                this.cards.forEach((card, index) => {
                    this.renderCard(grid, card, index);
                });
            }

            // Fade in
            setTimeout(() => {
                grid.style.opacity = '1';
            }, 10);
        }, 200);
    }

    renderCard(container, card, index) {
        const cardEl = container.createDiv({ cls: 'corkboard-card' });
        cardEl.setAttribute('draggable', 'true');
        cardEl.dataset.index = index.toString();

        // Card content
        const content = cardEl.createDiv({ cls: 'card-content' });
        
        const title = content.createEl('h3', { 
            text: card.title, 
            cls: 'card-title' 
        });
        
        if (card.excerpt) {
            content.createEl('p', { 
                text: card.excerpt, 
                cls: 'card-excerpt' 
            });
        }

        // Add metadata footer
        if (card.wordCount !== undefined) {
            const metadata = content.createDiv({ cls: 'card-metadata' });
            
            // Word count
            const wordCountEl = metadata.createSpan({ cls: 'card-meta-item' });
            wordCountEl.createSpan({ text: '✎ ', cls: 'card-meta-icon' });
            wordCountEl.createSpan({ text: `${card.wordCount} words` });
            
            // Last modified (relative time)
            if (card.modified) {
                const modifiedEl = metadata.createSpan({ cls: 'card-meta-item' });
                modifiedEl.createSpan({ text: '◷ ', cls: 'card-meta-icon' });
                modifiedEl.createSpan({ text: this.getRelativeTime(card.modified) });
            }
        }

        // Click to open note
        cardEl.addEventListener('click', (e) => {
            if (!e.target.classList.contains('card-menu-btn')) {
                this.app.workspace.getLeaf(false).openFile(card.file);
            }
        });

        // Context menu
        cardEl.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showCardMenu(e, card);
        });

        // Drag and drop
        cardEl.addEventListener('dragstart', (e) => {
            this.draggedCard = cardEl;
            this.draggedCardIndex = index;
            cardEl.addClass('dragging');
            e.dataTransfer.effectAllowed = 'move';
        });

        cardEl.addEventListener('dragend', () => {
            cardEl.removeClass('dragging');
            this.draggedCard = null;
            this.draggedCardIndex = -1;
        });

        cardEl.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            
            if (this.draggedCard && this.draggedCard !== cardEl) {
                cardEl.addClass('drag-over');
            }
        });

        cardEl.addEventListener('dragleave', () => {
            cardEl.removeClass('drag-over');
        });

        cardEl.addEventListener('drop', (e) => {
            e.preventDefault();
            cardEl.removeClass('drag-over');
            
            if (this.draggedCardIndex !== -1) {
                const targetIndex = parseInt(cardEl.dataset.index || '0');
                
                if (this.draggedCardIndex !== targetIndex) {
                    // Reorder cards
                    const draggedCard = this.cards[this.draggedCardIndex];
                    this.cards.splice(this.draggedCardIndex, 1);
                    this.cards.splice(targetIndex, 0, draggedCard);
                    
                    // Update positions
                    this.cards.forEach((c, i) => c.position = i);
                    
                    this.renderCorkboard();
                    new Notice('Card moved');
                }
            }
        });
    }

    getRelativeTime(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        const months = Math.floor(days / 30);
        const years = Math.floor(days / 365);

        if (years > 0) return `${years}y ago`;
        if (months > 0) return `${months}mo ago`;
        if (days > 0) return `${days}d ago`;
        if (hours > 0) return `${hours}h ago`;
        if (minutes > 0) return `${minutes}m ago`;
        return 'just now';
    }

    showCardMenu(event, card) {
        const menu = new Menu();

        menu.addItem((item) => {
            item.setTitle('Open')
                .setIcon('file-text')
                .onClick(() => {
                    this.app.workspace.getLeaf(false).openFile(card.file);
                });
        });

        menu.addItem((item) => {
            item.setTitle('Open in new tab')
                .setIcon('file-plus')
                .onClick(() => {
                    this.app.workspace.getLeaf(true).openFile(card.file);
                });
        });

        menu.addItem((item) => {
            item.setTitle('Delete')
                .setIcon('trash')
                .onClick(async () => {
                    await this.app.vault.delete(card.file);
                    await this.loadCards();
                    this.renderCorkboard();
                    new Notice('Note deleted');
                });
        });

        menu.showAtMouseEvent(event);
    }

    showFolderSelector() {
        const modal = new FolderSelectorModal(this.app, (folder) => {
            this.setFolder(folder);
        });
        modal.open();
    }

    async onClose() {
        // Cleanup if needed
    }
}

// Folder selector modal
class FolderSelectorModal extends FuzzySuggestModal {
    constructor(app, onChooseFolder) {
        super(app);
        this.onChooseFolder = onChooseFolder;
        this.setPlaceholder('Select a folder...');
    }

    getItems() {
        const folders = ['/']; // Root folder
        
        const addFolders = (folder) => {
            folders.push(folder.path);
            folder.children.forEach(child => {
                if (child instanceof TFolder) {
                    addFolders(child);
                }
            });
        };

        const root = this.app.vault.getRoot();
        root.children.forEach(child => {
            if (child instanceof TFolder) {
                addFolders(child);
            }
        });

        return folders;
    }

    getItemText(item) {
        return item === '/' ? 'Root (All Notes)' : item;
    }

    onChooseItem(item) {
        this.onChooseFolder(item === '/' ? '' : item);
    }
}

// Main Plugin Class
class CorkboardPlugin extends Plugin {
    async onload() {
        console.log('Loading Corkboard plugin');

        // Load settings
        await this.loadSettings();

        // Register the corkboard view
        this.registerView(
            VIEW_TYPE_CORKBOARD,
            (leaf) => new CorkboardView(leaf, this)
        );

        // Add settings tab
        this.addSettingTab(new CorkboardSettingTab(this.app, this));

        // Add ribbon icon to open corkboard
        this.addRibbonIcon('layout-grid', 'Open Corkboard', () => {
            this.activateCorkboardView();
        });

        // Add command to open corkboard
        this.addCommand({
            id: 'open-corkboard-view',
            name: 'Open Corkboard',
            callback: () => {
                this.activateCorkboardView();
            }
        });

        // Add command to add current folder to corkboard
        this.addCommand({
            id: 'show-folder-in-corkboard',
            name: 'Show current folder in Corkboard',
            callback: () => {
                const activeFile = this.app.workspace.getActiveFile();
                if (activeFile) {
                    const folder = activeFile.parent;
                    this.activateCorkboardView(folder?.path);
                }
            }
        });
    }

    async loadSettings() {
        this.settings = Object.assign(new CorkboardSettings(), await this.loadData());
    }

    async saveSettings() {
        await this.saveData(this.settings);
        
        // Update all open corkboard views
        const leaves = this.app.workspace.getLeavesOfType(VIEW_TYPE_CORKBOARD);
        leaves.forEach(leaf => {
            if (leaf.view instanceof CorkboardView) {
                leaf.view.applyCustomBackground();
            }
        });
    }

    async activateCorkboardView(folderPath) {
        const { workspace } = this.app;

        let leaf = null;
        const leaves = workspace.getLeavesOfType(VIEW_TYPE_CORKBOARD);

        if (leaves.length > 0) {
            // A corkboard view already exists, use it
            leaf = leaves[0];
        } else {
            // Create a new leaf in the right split
            leaf = workspace.getRightLeaf(false);
            if (leaf) {
                await leaf.setViewState({ type: VIEW_TYPE_CORKBOARD, active: true });
            }
        }

        // Reveal the leaf
        if (leaf) {
            workspace.revealLeaf(leaf);
            
            // If a folder path was provided, update the view
            if (folderPath && leaf.view instanceof CorkboardView) {
                leaf.view.setFolder(folderPath);
            }
        }
    }

    onunload() {
        console.log('Unloading Corkboard plugin');
    }
}

// Settings Tab
class CorkboardSettingTab extends PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display() {
        const { containerEl } = this;
        containerEl.empty();

        containerEl.createEl('h2', { text: 'Corkboard Settings' });

        // Use custom background toggle
        new Setting(containerEl)
            .setName('Use custom background')
            .setDesc('Enable to use a custom background image instead of the default cork texture')
            .addToggle(toggle => toggle
                .setValue(this.plugin.settings.useCustomBackground)
                .onChange(async (value) => {
                    this.plugin.settings.useCustomBackground = value;
                    await this.plugin.saveSettings();
                }));

        // Custom background URL
        new Setting(containerEl)
            .setName('Custom background URL')
            .setDesc('Enter a URL to an image to use as the corkboard background (works best with seamless textures)')
            .addText(text => text
                .setPlaceholder('https://example.com/image.jpg')
                .setValue(this.plugin.settings.customBackgroundUrl)
                .onChange(async (value) => {
                    this.plugin.settings.customBackgroundUrl = value;
                    await this.plugin.saveSettings();
                }));

        containerEl.createEl('p', { 
            text: '💡 Tip: For best results, use a seamless tileable texture image.',
            cls: 'setting-item-description'
        });
    }
}

module.exports = CorkboardPlugin;
